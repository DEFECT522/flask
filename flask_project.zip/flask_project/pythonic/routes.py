from pythonic.models import User, Goal
from flask import Flask, render_template, url_for, redirect, flash, request
from pythonic.forms import RegisterationForm, LoginForm, GoalForm
from pythonic import app, bcrypt, db
from flask_login import login_user, current_user, logout_user, login_required


@app.route('/')
def index():
    return render_template('home.html', puplic='public')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = RegisterationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash(f'Account created for {form.username.data}!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)



@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            flash('You have been logged in!', 'success')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check credentials', 'danger')
    return render_template('login.html', title='Login', form=form)


@app.route('/logout')
def logout():
     logout_user()
     return redirect(url_for('home'))



@app.route('/goals')
@login_required
def goals_dashboard():
    goals = Goal.query.filter_by(user_id=current_user.id).all()
    total_points = sum(goal.points for goal in goals)
    total_goals = len(goals)
    percentage = 0
    if total_goals > 0:
        percentage = int(sum(goal.points for goal in goals) / (total_goals * 365) * 100)
    return render_template('goals_dashboard.html', total_points=total_points, total_goals=total_goals, percentage=percentage)

@app.route('/goals/add', methods=['GET', 'POST'])
@login_required
def add_goal():
    form = GoalForm()
    if form.validate_on_submit():
        goal = Goal(name=form.name.data, description=form.description.data, owner=current_user)
        db.session.add(goal)
        db.session.commit()
        flash('Goal added successfully!', 'success')
        return redirect(url_for('all_goals'))
    return render_template('add_goal.html', form=form)

@app.route('/goals/all')
@login_required
def all_goals():
    goals = Goal.query.filter_by(user_id=current_user.id).all()
    return render_template('all_goals.html', goals=goals)

@app.route('/goal/<int:goal_id>/increase')
@login_required
def increase_points(goal_id):
    goal = Goal.query.get_or_404(goal_id)
    if goal.owner != current_user:
        flash('Access denied.', 'danger')
        return redirect(url_for('goals_dashboard'))
    goal.points += 1
    db.session.commit()
    return redirect(url_for('all_goals'))

@app.route('/goal/<int:goal_id>/decrease')
@login_required
def decrease_points(goal_id):
    goal = Goal.query.get_or_404(goal_id)
    if goal.owner != current_user:
        flash('Access denied.', 'danger')
        return redirect(url_for('goals_dashboard'))
    if goal.points > 0:
        goal.points -= 1
    db.session.commit()
    return redirect(url_for('all_goals'))